### MODEL Implementation Project

After opening the 'Project_Final' folder, we have a CMakeLists.txt file, a test folder, for testing if we're obtaining correct matrix results using our functions, and a main folder, which contains: \n
* src for the source code
* time_testing_output for testing the time of our functions
* graphs where we produced graphs of the time complexities of our algorithms

To run this program, follow the steps:
1. Make a build directory for cmake. Run:
    ```
    mkdir build
    ```
2. Change the directory
2. Run CMake to generate the build system
    ```
    cd build
    cmake ..
    ```
3. Build the project and the tests:
    ```
    make
    ```
4. Run the test
    ```
    ctest
    ```
5. Run the main program
    ```
    ./bin/my_program
    ```