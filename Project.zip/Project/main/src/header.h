#ifndef MY_HEADER_H
#define MY_HEADER_H

// GENERAL FUNCTIONS
/** 1. print a matrix to output 
 *      input:  m - height of matrix
 *              n - width of matrix
 *              H - matrix of size mxn */
void printMatrix(int m, int n, double **H);

/** 2. padding a matrix with zero columns and rows
 *      input:  A - matrix with size mxn
 *      output: A_pad - matrix after zero-padding with size max x max */
void zeroPadding(int m, int n, int max, double **A, double **A_pad);

/** 3. Create a matrix with random coefficients in range [-1;1]
*       input:  m,n - matrix size
*       output: A - matrix with random coef */
void random_matrix(int m, int n, double **A);

/** 4. Check if an user input is a positive integer
 *      output: 0 - if not a positive integer
 *              the user input in int - if a positive integer
 */
int scan_entry();

// MATRIX MULTIPLICATION
/** 5. calculate the matrix multiplication using Naive method
*       input:  A - matrix of size mxn
*               B - matrix of size nxp
*       output: C - matrix of size mxp */
void multiplyNaive(int m,int n, int p, double **A, double **B,double **C);

/** 6. Calculate the matrix multiplication using Strassen method
*       input:  A - matrix of size mxn
*               B - matrix of size nxp
*       output: C - matrix of size mxp */ 
void multiplyStrassen(int m, int n, int p, double **A, double **B, double **C);


// LU decomposition
/** 7. Calculate LU decomposition
*       input:  A - matrix of size nxn
*       output: L - lower triangular with 1s on the diagonal
*               U - upper triangular */
void LU(int n, double **L, double **U, double **A);

/** 8. Solving LU linear system
*       Ax = b
*       input:  L,U matrices
*               E- matrix b
*       ouput:  C- matrix x */
void LU_linear_solving(int n, double **L, double **U, double **C, double **E);

// INVERSION
/** 9. Inverse using LU decomposition
*       input: A matrix
        output: inverse A matrix*/
void inverseMatrix_LU(int n, double **A, double **invA);

/** 10. Inverse using Strassen Algorithm with Strassen-based Multiplication
 *      input: A matrix
 *      output: inverse A matrix */
void inverseMatrix_Strassen_Strassen(int n, double **A, double **C);

/** 11. Inverse using Strassen Algorithm with Naive-based Multiplication
 *      input: A matrix
 *      output: inverse A matrix */
void inverseMatrix_Strassen_Naive(int n, double **A, double **C);
#endif