#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "header.h"
#include <ctype.h> 

//printed a dynamic allocation matrix of size mxn
void printMatrix(int m, int n, double **H){
    // loop through each element of the matrix
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            printf("%.10f\t", H[i][j]); // print the element with 10 number after the decimal point
        }   
        printf("\n");
    }
    printf("\n");
    return;
}

// Padding a dynamic allocation matrix of size m x n to size max x max
// Store the new matrix of size max x max to A_pad
void zeroPadding(int m, int n, int max, double **A, double **A_pad){
    // loop through each element of A_pad
    for(int i =0; i<max;i++){
        for(int j = 0; j<max;j++){
            A_pad[i][j] = 0; // initialize the element value = 0 (zero padding)
            // we have a zero padding on the top and left of the matrix
            if(i>=max-m & j >= max-n){
                A_pad[i][j] = A[i-max+m][j-max+n]; // copy the element from A to A_pad to the right and bottom
            }
        }
    }
}

// Assign the random matrix A of size m x n with value of floating-point number in double precision in range [-1;1]
void random_matrix(int m, int n, double **A){
    srand(time(NULL));

    // loop through each element of A
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++){
            // create random number from [-1,1]
            double r = ((double)rand() / RAND_MAX) * 2.0f - 1.0f;
            // store this number to the element of A
            A[i][j] = r;
        }
    }
}

// Check the user input value if it's a positive integer 
// return 0 if not a positive integer
// return the number if a positive integer
int scan_entry(){
    char str[10];
    scanf("%s",str); // get the user input as a string

    // check through each char of the string
    for (int i = 0; str[i] != '\0'; i++) {
        // if (i == 0 && str[i] == '-') { // Allow negative sign for integers
        //     continue;
        // }
        if (!isdigit(str[i])) { // check if this number is not an integer
            return 0; // Non-digit character found
        }
    }
    int n = strtol(str, NULL, 10); // if it's an integer => we change the string to number
    // return this number
    return n;
} 