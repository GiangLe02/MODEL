#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "header.h"

// print the main menu of the program
void menu(){
    printf("Main Menu\n");
    printf("1. Naive (Classical) Matrix Multiplication\n");
    printf("2. Strassen Matrix Multiplication\n");
    printf("3. LU decomposition\n");
    printf("4. Inverse Matrix using LU\n");
    printf("5. Inverse matrix using Strassen\n");
    printf("6. Compare Naive and Strassen Matrix Multiplication\n");
    printf("7. Compare LU and Strassen Matrix Inversion\n");
    printf("8. Exit\n");
}

void Naive_Multiplication(){    
    int m,n,p;

    // We want to store the time to compute Naive  Multiplication to a file
    FILE *file = fopen("../main/time_testing_output/NaiveMult_Time_testing.txt", "a");

    printf("We're multiplying 2 matrices of size m x n and n x p using the Naive method.\n");
    // Ask user to enter the input for the sizes of the Matrices (m x n and n x p)
    do{
        printf("Enter a positive number for m: ");
        m=scan_entry();
        if(m==0){
            printf("Wrong input!\n");
        }
    } while(m==0);
    do{
        printf("Enter a positive number for n: ");
        n=scan_entry();
        if(n==0){
            printf("Wrong input!\n");
        }
    } while(n==0);

    do{
        printf("Enter a positive number for p: ");
        p=scan_entry();
        if(p==0){
            printf("Wrong input!\n");
        }
    } while(p==0);

    // Store the sizes of m,n,p to the output file
    fprintf(file ,"Multiplying Matrices of size %dx%d and %dx%d\n", m, n, n, p);

    // Intitialize the matrices with dynamic allocations
    double **A,**B;
    A = (double**)malloc(m* sizeof(double*));
    for(int i=0; i<m;i++){
        A[i] = (double*)malloc(n*sizeof(double));
    }
    B = (double**)malloc(n* sizeof(double*));
    for(int i=0; i<n;i++){
        B[i] = (double*)malloc(p*sizeof(double));
    }

    // Assign random values to the input matrices A and B
    random_matrix(m,n,A);
    random_matrix(n,p,B);

    // Print Matrix A
    printf("A = \n");
    printMatrix(m,n,A);

    // Print Matrix B
    printf("B = \n");
    printMatrix(n,p,B);

    // initialize the result Matrix C = A*B of size m x p
    double **C;
    C = (double**)malloc(m* sizeof(double*));
    for(int i=0; i<m;i++){
        C[i] = (double*)malloc(p*sizeof(double));
    }

    clock_t start_time, end_time;
    double time_taken;

    // Recording the start time
    start_time = clock();

    // Calling our function to compute Naive Multiplication
    multiplyNaive(m,n,p,A,B,C);

    // Recording the end time
    end_time = clock();

    // Calculating the time taken to compute naive multiplication in seconds
    time_taken = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

    // print the result matrix and the time to compute this matrix
    printf("The resulting matrix using the Naive method is : \n");
    printMatrix(m,p, C);
    printf("Time to compute Naive matrix multiplication is %f seconds\n", time_taken);

    // store the time to the output file
    fprintf(file, "Computation time for Naive Matrix Multiplication: %.10f seconds \n\n", time_taken);
    fclose(file);

    // free the memory
    for(int i=0; i<m;i++){
        free(A[i]);
        free(C[i]);
    }
    for(int i=0;i<n;i++){free(B[i]);}
    free(A); free(B); free(C);
}

void Strassen_Multiplication(){
    //  We want to store the time to compute Strassen Multiplication to a file
    FILE *file = fopen("../main/time_testing_output/StrassenMult_Time_testing.txt", "a");
    int m,n,p;
    printf("We're multiplying 2 matrices of size mxn and nxp using Strassen Algorithm.\n");
    // Ask user to enter the input for the sizes of the Matrices (m x n and n x p)
    do{
        printf("Enter a positive number for m: ");
        m=scan_entry();
        if(m==0){
            printf("Wrong input!\n");
        }
    } while(m==0);
    do{
        printf("Enter a positive number for n: ");
        n=scan_entry();
        if(n==0){
            printf("Wrong input!\n");
        }
    } while(n==0);

    do{
        printf("Enter a positive number for p: ");
        p=scan_entry();
        if(p==0){
            printf("Wrong input!\n");
        }
    } while(p==0);
    
    // Store the sizes of m,n,p to the output file
    fprintf(file ,"Multiplying Matrices of size %dx%d and %dx%d\n", m, n, n, p);

    // Initialize the input matrices A and B
    double **A,**B;
    A = (double**)malloc(m* sizeof(double*));
    for(int i=0; i<m;i++){
        A[i] = (double*)malloc(n*sizeof(double));
    }
    B = (double**)malloc(n* sizeof(double*));
    for(int i=0; i<n;i++){
        B[i] = (double*)malloc(p*sizeof(double));
    }

    // Assign random values to the input matrices A and B
    random_matrix(m,n,A);
    random_matrix(n,p,B);

    // print matrix A
    printf("A = \n");
    printMatrix(m,n,A);

    // print matrix B
    printf("B = \n");
    printMatrix(n,p,B);

    // initialize the result Matrix C = A*B of size m x p
    double **C1;
    C1 = (double**)malloc(m* sizeof(double*));
    for(int i=0; i<m;i++){
        C1[i] = (double*)malloc(p*sizeof(double));
    }

    clock_t start_time, end_time;
    double time_taken;

    // Recording the start time
    start_time = clock();

    // Calling the function to compute Strassen Multiplication
    multiplyStrassen(m,n,p,A,B,C1);

    // Recording the end time
    end_time = clock();

    // Calculating the time taken to compute Strassen Multiplication in seconds
    time_taken = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

    // print the result matrix
    printf("The resulting matrix using Strassen method is : \n");
    printMatrix(m,p, C1);

    // print the computation time
    printf("Time to compute Strassen matrix multiplication is %f seconds\n", time_taken);
    
    // save the computation time to the output file
    fprintf(file, "Computation time for Strassen Matrix Multiplication: %.10f seconds \n\n", time_taken);
    fclose(file);

    // free memory
    for(int i=0; i<m;i++){
        free(A[i]);
        free(C1[i]);
    }
    for(int i=0;i<n;i++){free(B[i]);}
    free(A); free(B); free(C1);
}

void LU_Decomposition(){
    //  We want to store the time to compute LU decomposition to a file
    FILE *file = fopen("../main/time_testing_output/LU_Time_testing.txt", "a");

    int n;
    printf("We're computing the LU decomposition of matrix A having size nxn.\n");
    
    // Ask user to enter the input for the sizes of the Matrix (n x n)
    do{
        printf("Enter a positive number for n: ");
        n=scan_entry();
        if(n==0){
            printf("Wrong input!\n");
        }
    } while(n==0);

    // Store the size n to the output file
    fprintf(file ,"Matrix size of %dx%d\n", n, n);

    // initialize the input matrix A and output matrix L, U
    // all of them are in size n x n
    double **A,**L, **U;
    A = (double**)malloc(n* sizeof(double*));
    L = (double**)malloc(n* sizeof(double*));
    U = (double**)malloc(n* sizeof(double*));

    for(int i=0; i<n;i++){
        A[i] = (double*)malloc(n*sizeof(double));
        L[i] = (double*)malloc(n*sizeof(double));
        U[i] = (double*)malloc(n*sizeof(double));
    }

    // Assign random value to matrix A
    random_matrix(n,n,A);
    // print matrix A
    printf("A = \n");
    printMatrix(n,n,A);

    clock_t start_time, end_time;
    double time_taken;

    // Recording the start time
    start_time = clock();

    // Calling our LU function
    LU(n,L,U,A);

    // Recording the end time
    end_time = clock();

    // Calculating the time taken to compute LU decomposition in seconds
    time_taken = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

    // Print Matrix L
    printf("L = \n");
    printMatrix(n,n,L);
    // Print Matrix U
    printf("U = \n");
    printMatrix(n,n,U);
    // print computation time of LU
    printf("Time to compute LU decomposition is %f seconds\n", time_taken);
    // Store the computation time to the output file
    fprintf(file, "Computation time for LU Decomposition: %.10f seconds \n\n", time_taken);
    fclose(file);

    // free memory
    for(int i=0; i<n;i++){
        free(A[i]);
        free(L[i]);
        free(U[i]);
    }
    free(A); free(L); free(U);
    return;
}

void Inverse_LU(){
    int n;
    //  We want to store the time to compute Inversion using LU to a file
    FILE *file = fopen("../main/time_testing_output/InvLU_Time_testing.txt", "a");

    // Ask user input for the size of the matrix A (n x n)
    printf("We're computing the inverse of matrix A having size nxn using its LU decomposition.\n");
    do{
        printf("Enter a positive number for n: ");
        n=scan_entry();
        if(n==0){
            printf("Wrong input!\n");
        }
    } while(n==0);  

    // Save the size n to the output file
    fprintf(file ,"Inverting using LU a Matrix of size %dx%d \n", n, n);

    // Initilize the input matrix A and the output matrix invA
    double **A,**invA;
    A = (double**)malloc(n* sizeof(double*));
    invA = (double**)malloc(n* sizeof(double*));
    for(int i=0; i<n;i++){
        A[i] = (double*)malloc(n*sizeof(double));
        invA[i] = (double*)malloc(n*sizeof(double));
    }

    // Assign random value for matrix A
    random_matrix(n,n,A);

    // print matrix A
    printf("A = \n");
    printMatrix(n,n,A);

    clock_t start_time, end_time;
    double time_taken;

    // Recording the start time
    start_time = clock();

    // Calling our inverse LU function
    inverseMatrix_LU(n,A,invA);

    // Recording the end time
    end_time = clock();

    // Calculating the time taken to compute inversion using LU in seconds
    time_taken = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;    

    // print the result matrix
    printf("A-1 = \n");
    printMatrix(n,n,invA);
    //print the computation time
    printf("Time to compute the inverse matrix A is %f seconds\n", time_taken);
    
    // Save the computation time to the output file
    fprintf(file, "Computation time for Matrix Inversion using LU: %.10f seconds \n\n", time_taken);
    fclose(file);

    // free memory
    for(int i=0; i<n;i++){
        free(A[i]);
        free(invA[i]);
    }
    free(A); free(invA);
    return;
}

void Inverse_Strassen(){
    int n;
    //  We want to store the time to compute Strassen Inversion to a file
    FILE *file = fopen("../main/time_testing_output/InvStrassen_Time_testing.txt", "a");
    // Ask user input for the size of the matrix A (n x n)
    printf("We're computing the inverse of matrix A having size nxn using Strassen Algorithm.\n");
    do{
        printf("Enter a positive number for n: ");
        n=scan_entry();
        if(n==0){
            printf("Wrong input!\n");
        }
    } while(n==0); 

    // Save the size n to the output file
    fprintf(file ,"Inverting using Strassen a Matrix of size %dx%d \n", n, n);

    // Initialize input matrix A of size n x n and the output matrix invA of size n x n
    double **A,**invA;
    A = (double**)malloc(n* sizeof(double*));
    invA = (double**)malloc(n* sizeof(double*));
    for(int i=0; i<n;i++){
        A[i] = (double*)malloc(n*sizeof(double));
        invA[i] = (double*)malloc(n*sizeof(double));
    }

    // Assign the random values to the matrix A
    random_matrix(n,n,A);
    printf("original matrix:\n");
    printMatrix(n,n,A);
    printf("\n");

    clock_t start_time1, end_time1;
    double time_taken1;

    // Recording the start time
    start_time1 = clock();

    // Calling our inverse Strassen using Strassen multiplication function
    inverseMatrix_Strassen_Strassen(n,A,invA);

    // Recording the end time
    end_time1 = clock();

    // Calculating the time taken of inverse Strassen using Strassen multiplication in seconds
    time_taken1 = ((double)(end_time1 - start_time1)) / CLOCKS_PER_SEC;   
    
    // print the output inverse Matrix using Strassen Algorithm with Strassen multiplication
    printf("Inverse using Strassen and Strassen Mult: \n");
    printMatrix(n,n,invA);
    printf("\n");

    clock_t start_time2, end_time2;
    double time_taken2;

    // Recording the start time
    start_time2 = clock();

    // Calling our Inverse Strassen using Naive Multiplication function
    inverseMatrix_Strassen_Naive(n,A,invA);

    // Recording the end time
    end_time2 = clock();

    // Calculating the time taken to compute Inverse Strassen using Naive Multiplication in seconds
    time_taken2 = ((double)(end_time2 - start_time2)) / CLOCKS_PER_SEC; 

    // print the output inverse Matrix using Strassen Algorithm with Naive multiplication
    printf("Inverse using Strassen and Naive Mult: \n");
    printMatrix(n,n,invA);

    // Save the time to compute Inverse Strassen Algorithm to output file
    fprintf(file, "Computation time for Matrix Inversion using Strassen and Strassen Multiplication: %.10f seconds \n", time_taken1);
    printf("Time to compute the inverse matrix A using Strassen and Strassen multiplication is %f seconds\n", time_taken1);

    fprintf(file, "Computation time for Matrix Inversion using Strassen and Naive Multiplication: %.10f seconds \n\n", time_taken2);
    printf("Time to compute the inverse matrix A using Strassen and Naive multiplication is %f seconds\n", time_taken2);
    
    fclose(file);

    // free memory
    for(int i=0; i<n;i++){
        free(A[i]);
        free(invA[i]);
    }
    free(A); free(invA);
    return;
}

void Compare_Mult(){
    int m,n,p;
    
    //  We want to store both of the time to compute Multiplication in Naive and Strassen to a file
    FILE *file = fopen("../main/time_testing_output/MatrixMult_Time_testing.txt", "a");
    
    printf("We're multiplying 2 matrices of size mxn and nxp.\n");
    // Ask user to enter the input for the sizes of the Matrices (m x n and n x p)
    do{
        printf("Enter a positive number for m: ");
        m=scan_entry();
        if(m==0){
            printf("Wrong input!\n");
        }
    } while(m==0);
    do{
        printf("Enter a positive number for n: ");
        n=scan_entry();
        if(n==0){
            printf("Wrong input!\n");
        }
    } while(n==0);

    do{
        printf("Enter a positive number for p: ");
        p=scan_entry();
        if(p==0){
            printf("Wrong input!\n");
        }
    } while(p==0);

    // Initialize the input matrices A and B
    double **A,**B;
    A = (double**)malloc(m* sizeof(double*));
    for(int i=0; i<m;i++){
        A[i] = (double*)malloc(n*sizeof(double));
    }
    B = (double**)malloc(n* sizeof(double*));
    for(int i=0; i<n;i++){
        B[i] = (double*)malloc(p*sizeof(double));
    }

    // Save the size m,n,p to the output file
    fprintf(file ,"Matrix size of %dx%d and %dx%d\n", m, n, n, p);

    random_matrix(m,n,A);
    random_matrix(n,p,B);

    printf("A = \n");
    printMatrix(m,n,A);

    printf("B = \n");
    printMatrix(n,p,B);

    // Initialize the output matrices
    double **C1, **C2;
    C1 = (double**)malloc(m* sizeof(double*));
    C2 = (double**)malloc(m* sizeof(double*));
    for(int i=0; i<m;i++){
        C1[i] = (double*)malloc(p*sizeof(double));
        C2[i] = (double*)malloc(p*sizeof(double));
    }

    clock_t start_time1, end_time1;
    double time_taken1;

    // Recording the start time
    start_time1 = clock();

    // Calling our Naive Multiplication function
    multiplyNaive(m,n,p,A,B,C1);

    // Recording the end time
    end_time1 = clock();

    // Calculating the time taken to compute Naive Multiplication in seconds
    time_taken1 = ((double)(end_time1 - start_time1)) / CLOCKS_PER_SEC; 
    // Print the result matrix of Naive Multiplication
    printf("The resulting matrix using the Naive method is : \n");
    printMatrix(m,p, C1);

    clock_t start_time2, end_time2;
    double time_taken2;

    // Recording the start time
    start_time2 = clock();

    // Calling our Strassen Multiplication function
    multiplyStrassen(m,n,p,A,B,C2);

    // Recording the end time
    end_time2 = clock();

    // Calculating the time taken to compute Strassen Multiplication in seconds
    time_taken2 = ((double)(end_time2 - start_time2)) / CLOCKS_PER_SEC;  
    // Print the result matrix of Strassen Multiplication  
    printf("The resulting matrix using Strassen method is : \n");
    printMatrix(m,p, C2);

    // Print the computation time of Naive Multiplication
    printf("Time to compute the Naive Matrix Multiplication is %f seconds\n", time_taken1);
    // Print the computation time of Strassen Multiplication
    printf("Time to compute the Strassen Matrix Multiplication is %f seconds\n", time_taken2);

    // Save the computation time of Naive and Strassen Multiplication to the output file
    fprintf(file, "Computation time Naive: %.10f seconds \n", time_taken1);
    fprintf(file, "Computation time Strassen: %.10f seconds \n\n", time_taken2);
    fclose(file);

    // free memory
    for(int i=0; i<m;i++){
        free(A[i]);
        free(C1[i]);
        free(C2[i]);
    }
    for(int i=0;i<n;i++){free(B[i]);}
    free(A); free(B); free(C1); free(C2);
    return;
}

void Compare_Inv(){
    int n;
    //  We want to store the time to compute Inversion using LU, Strassen with Naive Multiplication and Strassen with Strassen Multiplication to a file
    FILE *file = fopen("../main/time_testing_output/MatrixInverse_Time_testing.txt", "a");

    // Ask user input for the size of the matrix A (n x n)
    printf("We're computing the inverse of matrix A having size nxn.\n");
    do{
        printf("Enter a positive number for n: ");
        n=scan_entry();
        if(n==0){
            printf("Wrong input!\n");
        }
    } while(n==0);

    // Save the size n to the output file
    fprintf(file ,"Matrix size of %dx%d\n", n, n);

    // Initialize the input matrix A
    // and the ouput matrix: invA1 - inverse matrix using LU decomposition
    //                       invA2 - inverse matrix using Strassen Algorithm with Strassen Multiplication
    //                       invA3 - inverse matrix using Strassen Algorithm with Naive Multiplication
    double **A,**invA1, **invA2, **invA3;
    A = (double**)malloc(n* sizeof(double*));
    invA1 = (double**)malloc(n* sizeof(double*));
    invA2 = (double**)malloc(n* sizeof(double*));
    invA3 = (double**)malloc(n* sizeof(double*));
    for(int i=0; i<n;i++){
        A[i] = (double*)malloc(n*sizeof(double));
        invA1[i] = (double*)malloc(n*sizeof(double));
        invA2[i] = (double*)malloc(n*sizeof(double));
        invA3[i] = (double*)malloc(n*sizeof(double));
    }

    // Assign random values to input matrix A
    random_matrix(n,n,A);

    // print matrix A
    printf("A = \n");
    printMatrix(n,n,A);

    clock_t start_time1, end_time1;
    double time_taken1;

    // Recording the start time
    start_time1 = clock();

    // Calling our inverse LU function
    inverseMatrix_LU(n,A,invA1);

    // Recording the end time
    end_time1 = clock();

    // Calculating the time taken using inverse LU in seconds
    time_taken1 = ((double)(end_time1 - start_time1)) / CLOCKS_PER_SEC;   

    // print the ouput matrix using inverse LU
    printf("A-1 using LU = \n");
    printMatrix(n,n,invA1);

    clock_t start_time2, end_time2;
    double time_taken2;

    // Recording the start time
    start_time2 = clock();

    // Calling our Strassen Inversion with Strassen Multiplication function
    inverseMatrix_Strassen_Strassen(n,A,invA2);

    // Recording the end time
    end_time2 = clock();

    // Calculating the time taken using Strassen Inversion with Strassen Multiplication in seconds
    time_taken2 = ((double)(end_time2 - start_time2)) / CLOCKS_PER_SEC;    
    // print the output matrix using Strassen Inversion with Strassen Multiplication
    printf("A-1 using Strassen with Strassen-Multiplication = \n");
    printMatrix(n,n,invA2); 

    clock_t start_time3, end_time3;
    double time_taken3;

    // Recording the start time
    start_time3 = clock();

    // Calling our Strassen Inversion with Naive Multiplication function
    inverseMatrix_Strassen_Naive(n,A,invA3);

    // Recording the end time
    end_time3 = clock();

    // Calculating the time taken of computing Strassen Inversion with Naive Multiplication function in seconds
    time_taken3 = ((double)(end_time3 - start_time3)) / CLOCKS_PER_SEC;   

    // print the output matrix using Strassen Inversion with Naive Multiplication 
    printf("A-1 using Strassen with Naive-Multiplication = \n");
    printMatrix(n,n,invA3);       

    // print the computation time of Inversion matrix using LU, Strassen with Strassen Multiplication and Strassen with Naive Multiplication
    printf("Time to compute inversion using LU is %f seconds\n", time_taken1);
    printf("Time to compute inversion using Strassen Strassen is %f seconds\n", time_taken2);
    printf("Time to compute inversion using Strassen Naive is %f seconds\n", time_taken3);
    
    // save the computation time to the output file
    fprintf(file, "Computation time LU: %.10f seconds \n", time_taken1);
    fprintf(file, "Computation time Strassen Strassen: %.10f seconds \n", time_taken2);
    fprintf(file, "Computation time Strassen Naive: %.10f seconds \n\n", time_taken3);
    fclose(file);
    
    // free the memory
    for(int i=0; i<n;i++){
        free(A[i]);
        free(invA1[i]);
        free(invA2[i]);
        free(invA3[i]);
    }
    free(A); free(invA1); free(invA2); free(invA3);
}

int main() {
    int menu_option; // contain the menu option taken from the user keyboard input
    printf("\n");
    printf("        MODEL PROJECT PROGRAM!!!\n");
    printf("------------------------------------------\n\n");
    do {
        menu(); // print the menu
        do{
            // Ask the user to enter an option from 1-8
            printf("\nPlease enter an option from the main menu: ");
            menu_option=scan_entry();
            // check if the user has entered a number from 1 to 8
            if(menu_option<=0 || menu_option>8){
                printf("Wrong input!\n");
            }
        } while(menu_option<=0 || menu_option>8); // Make the user enter the option again if the input is invalid (not 1-8)

        switch (menu_option)
        {
        // Option 1: Calling function to calculate Matrix Multiplication using Naive method
        case 1:
            Naive_Multiplication();
            break;
        // Option 2: Calling function to calculate Matrix Multiplication using Strassen Algorithm
        case 2:
            Strassen_Multiplication();
            break;
        // Option 3: Calling function to calculate LU Decomposition
        case 3:
            LU_Decomposition();
            break;
        // Option 4: Calling function to calculate Matrix Inversion using LU Decomposition
        case 4:
            Inverse_LU();
            break;
        // Option 5: Calling function to calculate Matrix Inversion using Strassen Algorithm
        case 5:
            Inverse_Strassen();
            break;
        // Option 6: Calling function to compare the 2 methods for Matrix Multiplication
        case 6:
            Compare_Mult();
            break;
        // Option 7: Calling function to compare the 2 methods for Matrix Inversion
        case 7:
            Compare_Inv();
            break;
        // Option 8: Exit the program
        case 8:
            break;
        default: // Wrong input
            printf("Invalid input! Please enter a number from 1 to 8\n");
            break;
        }
    } while(menu_option != 8); // recall the menu until user choose option to exit the program
    return 0;
}